/**
 * Britten Woodworking — site.js
 * Mobile nav · Dropdown touch · Scroll reveals · Form handler
 */

(function () {
  'use strict';

  /* =========================================================
     UTILITIES
  ========================================================= */

  function $(sel, ctx) { return (ctx || document).querySelector(sel); }
  function $$(sel, ctx) { return Array.from((ctx || document).querySelectorAll(sel)); }

  function onReady(fn) {
    if (document.readyState !== 'loading') fn();
    else document.addEventListener('DOMContentLoaded', fn);
  }

  /* =========================================================
     1. MOBILE NAV OVERLAY
     ─────────────────────────────────────────────────────────
     Burger button toggles a full-screen overlay.
     Work dropdown expands inline with an accordion.
     Trap focus while open. ESC closes.
  ========================================================= */

  function initMobileNav() {
    var burger   = $('.site-nav__burger');
    var navLinks = $('.site-nav__links');
    var overlay  = null;

    if (!burger || !navLinks) return;

    // Build the overlay element
    overlay = document.createElement('div');
    overlay.id = 'mobile-menu';
    overlay.className = 'mobile-overlay';
    overlay.setAttribute('aria-hidden', 'true');
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    overlay.setAttribute('aria-label', 'Navigation menu');

    // Clone the nav links into the overlay
    var clonedNav = navLinks.cloneNode(true);
    clonedNav.classList.add('mobile-nav__list');
    overlay.appendChild(clonedNav);

    // Add close button inside overlay
    var closeBtn = document.createElement('button');
    closeBtn.className = 'mobile-overlay__close';
    closeBtn.setAttribute('aria-label', 'Close menu');
    closeBtn.innerHTML = '&times;';
    overlay.insertBefore(closeBtn, overlay.firstChild);

    // Append to body
    document.body.appendChild(overlay);

    // Wire up Work dropdown accordion inside overlay
    var dropdownTrigger = overlay.querySelector('.site-nav__dropdown-trigger');
    var dropdownPanel   = overlay.querySelector('.site-nav__dropdown');

    if (dropdownTrigger && dropdownPanel) {
      dropdownPanel.style.display = 'none';
      dropdownTrigger.setAttribute('aria-expanded', 'false');

      dropdownTrigger.addEventListener('click', function (e) {
        e.preventDefault();
        var isOpen = dropdownPanel.style.display !== 'none';
        dropdownPanel.style.display = isOpen ? 'none' : 'block';
        dropdownTrigger.setAttribute('aria-expanded', isOpen ? 'false' : 'true');
      });
    }

    // Open
    function openNav() {
      overlay.classList.add('is-open');
      overlay.setAttribute('aria-hidden', 'false');
      burger.setAttribute('aria-expanded', 'true');
      burger.classList.add('is-active');
      document.body.style.overflow = 'hidden';
      // Shift burger lines to X
      var lines = $$('.site-nav__burger-line', burger);
      if (lines[0]) lines[0].style.transform = 'translateY(6px) rotate(45deg)';
      if (lines[1]) lines[1].style.transform = 'translateY(-6px) rotate(-45deg)';
      // Focus first link
      setTimeout(function () {
        var firstLink = overlay.querySelector('a, button');
        if (firstLink) firstLink.focus();
      }, 50);
    }

    // Close
    function closeNav() {
      overlay.classList.remove('is-open');
      overlay.setAttribute('aria-hidden', 'true');
      burger.setAttribute('aria-expanded', 'false');
      burger.classList.remove('is-active');
      document.body.style.overflow = '';
      var lines = $$('.site-nav__burger-line', burger);
      if (lines[0]) lines[0].style.transform = '';
      if (lines[1]) lines[1].style.transform = '';
      burger.focus();
    }

    burger.addEventListener('click', function () {
      overlay.classList.contains('is-open') ? closeNav() : openNav();
    });

    closeBtn.addEventListener('click', closeNav);

    // ESC to close
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && overlay.classList.contains('is-open')) closeNav();
    });

    // Tap outside content to close
    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) closeNav();
    });

    // Close when a nav link is clicked
    overlay.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', closeNav);
    });
  }

  /* =========================================================
     2. DESKTOP DROPDOWN — keyboard + aria-expanded
     ─────────────────────────────────────────────────────────
     Supplements the CSS :hover with keyboard support.
     Tab away or ESC closes the panel.
  ========================================================= */

  function initDesktopDropdown() {
    var items = $$('.site-nav__item--has-dropdown');

    items.forEach(function (item) {
      var trigger = item.querySelector('.site-nav__dropdown-trigger');
      var panel   = item.querySelector('.site-nav__dropdown');
      if (!trigger || !panel) return;

      function open() {
        trigger.setAttribute('aria-expanded', 'true');
        panel.style.display = 'block';
      }
      function close() {
        trigger.setAttribute('aria-expanded', 'false');
        panel.style.display = '';
      }

      // Mouse — CSS handles it, but keep aria in sync
      item.addEventListener('mouseenter', open);
      item.addEventListener('mouseleave', close);

      // Keyboard — Enter/Space on trigger
      trigger.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          var isOpen = trigger.getAttribute('aria-expanded') === 'true';
          isOpen ? close() : open();
        }
        if (e.key === 'Escape') close();
      });

      // Close when focus leaves the item entirely
      item.addEventListener('focusout', function (e) {
        if (!item.contains(e.relatedTarget)) close();
      });
    });
  }

  /* =========================================================
     3. SCROLL REVEALS
     ─────────────────────────────────────────────────────────
     Elements with data-reveal fade+slide in when they enter
     the viewport. Uses IntersectionObserver — no scroll jank.
     Falls back gracefully if IO not supported.
  ========================================================= */

  function initScrollReveals() {
    if (!window.IntersectionObserver) return;

    var targets = $$('[data-reveal]');
    if (!targets.length) return;

    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-revealed');
          observer.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.12,
      rootMargin: '0px 0px -40px 0px'
    });

    targets.forEach(function (el) {
      el.classList.add('will-reveal');
      observer.observe(el);
    });
  }

  /* =========================================================
     4. CONTACT FORM HANDLER
     ─────────────────────────────────────────────────────────
     Works with Netlify Forms out of the box.
     Adds client-side validation + success/error feedback.
     No external dependencies.
  ========================================================= */

  function initForms() {
    var forms = $$('.contact-form');

    forms.forEach(function (form) {
      // Add Netlify attributes if deploying to Netlify
      // (safe to have even on non-Netlify hosts — just ignored)
      form.setAttribute('data-netlify', 'true');
      if (!form.getAttribute('name')) {
        form.setAttribute('name', 'contact');
      }
      // Required hidden input for Netlify
      if (!form.querySelector('input[name="form-name"]')) {
        var hidden = document.createElement('input');
        hidden.type  = 'hidden';
        hidden.name  = 'form-name';
        hidden.value = form.getAttribute('name');
        form.insertBefore(hidden, form.firstChild);
      }

      // Build status message element
      var status = document.createElement('p');
      status.className = 'contact-form__status';
      status.setAttribute('aria-live', 'polite');
      status.setAttribute('role', 'status');
      form.appendChild(status);

      form.addEventListener('submit', function (e) {
        e.preventDefault();

        // Basic client-side validation
        var requiredFields = $$('[required]', form);
        var valid = true;

        requiredFields.forEach(function (field) {
          field.classList.remove('contact-form__input--error');
          if (!field.value.trim()) {
            field.classList.add('contact-form__input--error');
            field.focus();
            valid = false;
          }
          // Email format check
          if (field.type === 'email' && field.value) {
            var emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(field.value);
            if (!emailOk) {
              field.classList.add('contact-form__input--error');
              valid = false;
            }
          }
        });

        if (!valid) {
          status.textContent   = 'Please fill in all required fields.';
          status.style.color   = 'var(--color-accent)';
          return;
        }

        // Submit
        var submitBtn = form.querySelector('[type="submit"]');
        var originalText = submitBtn ? submitBtn.textContent : '';
        if (submitBtn) {
          submitBtn.disabled     = true;
          submitBtn.textContent  = 'Sending\u2026';
        }
        status.textContent = '';

        var formData = new FormData(form);

        fetch('/', {
          method:  'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body:    new URLSearchParams(formData).toString()
        })
        .then(function (response) {
          if (response.ok) {
            status.textContent = 'Message sent \u2014 I\u2019ll be in touch shortly.';
            status.style.color = 'var(--color-accent)';
            form.reset();
          } else {
            throw new Error('Server error ' + response.status);
          }
        })
        .catch(function () {
          // Fallback: open mailto if fetch fails (e.g. non-Netlify host)
          var email   = 'brittenwoodworkingcompany@gmail.com';
          var subject = encodeURIComponent('Commission enquiry from brittenwoodworking.com');
          var name    = (form.querySelector('[name="first_name"]') || {}).value || '';
          var message = (form.querySelector('[name="message"]') || {}).value || '';
          var body    = encodeURIComponent('Name: ' + name + '\n\n' + message);
          window.location.href = 'mailto:' + email + '?subject=' + subject + '&body=' + body;
          status.textContent = 'Opening your email client\u2026';
          status.style.color = 'var(--color-text-secondary)';
        })
        .finally(function () {
          if (submitBtn) {
            submitBtn.disabled    = false;
            submitBtn.textContent = originalText;
          }
        });
      });

      // Clear error state on input
      $$('[required]', form).forEach(function (field) {
        field.addEventListener('input', function () {
          field.classList.remove('contact-form__input--error');
        });
      });
    });
  }

  /* =========================================================
     5. SMOOTH ANCHOR SCROLL
     ─────────────────────────────────────────────────────────
     Accounts for sticky nav height when jumping to #anchors.
  ========================================================= */

  function initSmoothScroll() {
    $$('a[href^="#"]').forEach(function (a) {
      a.addEventListener('click', function (e) {
        var target = document.querySelector(a.getAttribute('href'));
        if (!target) return;
        e.preventDefault();
        var navHeight = ($('.site-nav') || {}).offsetHeight || 72;
        var top = target.getBoundingClientRect().top + window.scrollY - navHeight - 16;
        window.scrollTo({ top: top, behavior: 'smooth' });
      });
    });
  }

  /* =========================================================
     INIT
  ========================================================= */

  onReady(function () {
    initMobileNav();
    initDesktopDropdown();
    initScrollReveals();
    initForms();
    initSmoothScroll();
  });

})();